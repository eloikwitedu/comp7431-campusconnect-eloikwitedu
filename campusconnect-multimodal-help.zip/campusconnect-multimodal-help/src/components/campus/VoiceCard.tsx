import { lazy, Suspense } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { Mic } from "lucide-react";

import { Button } from "@/components/ui/button";

// Public agent ID only. No API keys or signed URLs belong in browser code.
const ELEVENLABS_AGENT_ID = "agent_6101m5x6d64rfp9vdaqsjqyxvszb";

// The voice toolkit is browser-only, so it is loaded after the page is interactive.
const VoiceControls = lazy(() => import("@/components/campus/VoiceControls"));

function LoadingButton() {
  return (
    <Button size="lg" disabled>
      <Mic aria-hidden />
      Loading voice assistant…
    </Button>
  );
}

export function VoiceCard() {
  return (
    <section aria-labelledby="cc-voice-heading" className="cc-card p-6 sm:p-8">
      <div className="flex items-start gap-4">
        <span
          aria-hidden
          className="grid size-12 shrink-0 place-items-center rounded-full bg-secondary text-secondary-foreground"
        >
          <Mic className="size-6" />
        </span>
        <div>
          <h2 id="cc-voice-heading" className="text-2xl font-semibold">
            Ask by voice
          </h2>
          <p className="mt-2 text-muted-foreground">
            Talk to the CampusConnect AI voice assistant about approved IT topics. Nothing plays
            until you start, and your browser will ask before using the microphone. Do not say
            passwords, recovery codes, or student records.
          </p>
        </div>
      </div>
      <div className="mt-5">
        <ClientOnly fallback={<LoadingButton />}>
          <Suspense fallback={<LoadingButton />}>
            <VoiceControls agentId={ELEVENLABS_AGENT_ID} />
          </Suspense>
        </ClientOnly>
      </div>
    </section>
  );
}
