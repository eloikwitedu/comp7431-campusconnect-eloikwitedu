import { useRef, useState } from "react";
import { FileText, Keyboard, PlayCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { TEXT_INPUT_ID } from "@/components/campus/TextAsk";

// Public HeyGen share embed (works without sign-in per week-8 validation).
const HEYGEN_EMBED_URL = "https://app.heygen.com/embeds/0c5710e63e5f4c5b8d7060c5eae7c13a";

const TRANSCRIPT = [
  "Hello. I am an AI-generated CampusConnect presenter, not a live staff member. You can use CampusConnect for approved campus IT help.",
  "Ask about password resets, secure campus Wi-Fi, or the IT Service Desk. Please do not share passwords, recovery codes, student records, or other private information.",
  "If the chatbot cannot support an answer from its approved guide, it will direct you to a human. This video is a prerecorded introduction. You can read the same script in our GitHub project.",
];

export function VideoCard() {
  // The player is only loaded after an explicit click, so nothing can autoplay.
  const [loaded, setLoaded] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const transcriptRef = useRef<HTMLDivElement>(null);

  function focusTextInput() {
    const input = document.getElementById(TEXT_INPUT_ID);
    input?.scrollIntoView({ block: "center" });
    input?.focus({ preventScroll: true });
  }

  function toggleTranscript() {
    const next = !showTranscript;
    setShowTranscript(next);
    if (next) requestAnimationFrame(() => transcriptRef.current?.focus());
  }

  return (
    <section aria-labelledby="cc-video-heading" className="cc-card p-6 sm:p-8">
      <h2 id="cc-video-heading" className="text-2xl font-semibold">
        Watch the orientation
      </h2>
      <p className="mt-2 text-muted-foreground">
        A short prerecorded introduction to what CampusConnect can help with. It does not answer
        questions.
      </p>

      <div className="mt-5 aspect-video w-full overflow-hidden rounded-xl">
        {loaded ? (
          <iframe
            src={HEYGEN_EMBED_URL}
            title="CampusConnect orientation video with an AI-generated presenter"
            className="size-full border-0"
            allow="encrypted-media; fullscreen"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />
        ) : (
          <div className="cc-media flex size-full flex-col items-center justify-center gap-4 p-6 text-center">
            <Button variant="onMedia" size="lg" onClick={() => setLoaded(true)}>
              <PlayCircle aria-hidden className="size-6" />
              Load orientation video
            </Button>
            <p className="max-w-sm text-sm">
              The player loads when you choose it. Press play inside the player to start.
            </p>
          </div>
        )}
      </div>

      <p className="cc-notice mt-3 rounded-md px-4 py-2 font-semibold">
        AI-generated presenter — not a live staff member.
      </p>

      <div className="mt-5 flex flex-wrap gap-3">
        <Button variant="outline" size="lg" onClick={focusTextInput}>
          <Keyboard aria-hidden />
          Use text instead
        </Button>
        <Button
          variant="outline"
          size="lg"
          onClick={toggleTranscript}
          aria-expanded={showTranscript}
          aria-controls="cc-transcript"
        >
          <FileText aria-hidden />
          Read video transcript
        </Button>
      </div>

      <div
        id="cc-transcript"
        ref={transcriptRef}
        tabIndex={-1}
        hidden={!showTranscript}
        aria-labelledby="cc-transcript-heading"
        role="region"
        className="mt-5 rounded-xl bg-muted p-5"
      >
        <h3 id="cc-transcript-heading" className="text-lg font-semibold">
          Video transcript
        </h3>
        <div className="mt-2 space-y-3">
          {TRANSCRIPT.map((paragraph) => (
            <p key={paragraph}>{paragraph}</p>
          ))}
        </div>
      </div>
    </section>
  );
}
