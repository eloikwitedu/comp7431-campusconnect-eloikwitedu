import { useCallback, useState } from "react";
import { ConversationProvider, useConversation } from "@elevenlabs/react";
import { Loader2, Mic, MicOff, PhoneOff } from "lucide-react";

import { Button } from "@/components/ui/button";

type Line = { id: number; role: "user" | "agent"; text: string };

function Controls({ agentId }: { agentId: string }) {
  const [lines, setLines] = useState<Line[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);

  const conversation = useConversation({
    onMessage: (m) =>
      setLines((prev) => [...prev.slice(-19), {
          id: m.event_id,
          role: m.role,
          // Drop voice-style tags such as "[happy]" from the readable transcript.
          text: m.message.replace(/\[[a-z\s-]+\]\s*/gi, "").trim(),
        },
      ]),
    onError: () => setError("The voice assistant had a problem. Please type your question instead."),
  });

  const { status, isSpeaking } = conversation;
  const connected = status === "connected";
  const connecting = starting || status === "connecting";

  const start = useCallback(async () => {
    setError(null);
    setStarting(true);
    try {
      // Explicit user click → mic permission prompt → session. Nothing starts on its own.
      await navigator.mediaDevices.getUserMedia({ audio: true });
      setLines([]);
      conversation.startSession({ agentId, connectionType: "websocket" });
    } catch {
      setError("Microphone access was blocked. Allow the microphone, or type your question instead.");
    } finally {
      setStarting(false);
    }
  }, [agentId, conversation]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        {connected ? (
          <>
            <Button size="lg" variant="destructive" onClick={() => conversation.endSession()}>
              <PhoneOff aria-hidden />
              End voice conversation
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => conversation.setMuted(!conversation.isMuted)}
              aria-pressed={conversation.isMuted}
            >
              {conversation.isMuted ? <MicOff aria-hidden /> : <Mic aria-hidden />}
              {conversation.isMuted ? "Unmute microphone" : "Mute microphone"}
            </Button>
          </>
        ) : (
          <Button size="lg" onClick={start} disabled={connecting}>
            {connecting ? <Loader2 aria-hidden className="animate-spin" /> : <Mic aria-hidden />}
            {connecting ? "Connecting…" : "Start voice conversation"}
          </Button>
        )}
      </div>

      <p role="status" className="text-sm font-semibold text-muted-foreground">
        {connected
          ? isSpeaking
            ? "The assistant is speaking."
            : "Listening — ask your IT question."
          : connecting
            ? "Connecting to the voice assistant…"
            : "Voice assistant is off."}
      </p>

      {error && (
        <p role="alert" className="cc-notice rounded-md px-4 py-2">
          {error}
        </p>
      )}

      {lines.length > 0 && (
        <div className="rounded-xl bg-muted p-4">
          <h3 className="text-base font-semibold">Conversation transcript</h3>
          <ul className="mt-2 space-y-2 text-sm" aria-live="polite">
            {lines.map((line) => (
              <li key={`${line.id}-${line.role}`}>
                <span className="font-bold">{line.role === "agent" ? "Assistant" : "You"}:</span>{" "}
                {line.text}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default function VoiceControls({ agentId }: { agentId: string }) {
  return (
    <ConversationProvider>
      <Controls agentId={agentId} />
    </ConversationProvider>
  );
}
