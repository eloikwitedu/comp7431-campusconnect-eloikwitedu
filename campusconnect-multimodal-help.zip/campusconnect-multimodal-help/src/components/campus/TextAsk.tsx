import { useId, useState, type FormEvent } from "react";
import { BookOpenCheck, ShieldAlert, UserRound } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  ACTION_MESSAGE,
  GUIDE_NAME,
  HANDOFF_MESSAGE,
  PRIVACY_MESSAGE,
  askGuide,
  type AskResult,
  type GuideSource,
} from "@/lib/campus-guide";

export const TEXT_INPUT_ID = "cc-question";

function SourceAnswer({ source, intro }: { source: GuideSource; intro?: string }) {
  return (
    <div className="space-y-4">
      {intro && <p className="font-semibold">{intro}</p>}
      <p>{source.summary}</p>
      <ol className="list-decimal space-y-1.5 pl-6">
        {source.steps.map((step) => (
          <li key={step}>{step}</li>
        ))}
      </ol>
      <div className="flex items-start gap-3 rounded-lg bg-secondary p-3 text-sm text-secondary-foreground">
        <BookOpenCheck aria-hidden className="mt-0.5 size-5 shrink-0" />
        <p>
          <span className="font-bold">
            Source: {source.id} — {source.title}
          </span>
          <br />
          {GUIDE_NAME} · Owner: {source.owner} · Reviewed {source.reviewed}
        </p>
      </div>
    </div>
  );
}

function ResultView({ result }: { result: AskResult }) {
  switch (result.kind) {
    case "answer":
      return <SourceAnswer source={result.source} />;
    case "action-refused":
      return <SourceAnswer source={result.source} intro={ACTION_MESSAGE} />;
    case "unsupported":
      return (
        <div className="cc-handoff flex items-start gap-3 rounded-lg p-4">
          <UserRound aria-hidden className="mt-0.5 size-5 shrink-0" />
          <p>{HANDOFF_MESSAGE}</p>
        </div>
      );
    case "private-data":
      return (
        <div className="cc-notice flex items-start gap-3 rounded-lg p-4">
          <ShieldAlert aria-hidden className="mt-0.5 size-5 shrink-0" />
          <p>{PRIVACY_MESSAGE}</p>
        </div>
      );
    case "empty":
      return <p>Please type a question first.</p>;
  }
}

export function TextAsk() {
  const [question, setQuestion] = useState("");
  const [result, setResult] = useState<AskResult | null>(null);
  const hintId = useId();

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const next = askGuide(question);
    setResult(next);
    // Never keep a message that may contain private data on screen.
    if (next.kind === "private-data") setQuestion("");
  }

  return (
    <section aria-labelledby="cc-text-heading" className="cc-card p-6 sm:p-8">
      <p className="cc-eyebrow">Primary path · Text</p>
      <h2 id="cc-text-heading" className="mt-1 text-2xl font-semibold sm:text-3xl">
        Ask a question
      </h2>
      <p className="mt-2 text-muted-foreground">
        Answers come only from the approved IT Support guide and always show their source.
      </p>

      <form onSubmit={onSubmit} className="mt-6 space-y-3">
        <label htmlFor={TEXT_INPUT_ID} className="block font-semibold">
          Your IT question
        </label>
        <textarea
          id={TEXT_INPUT_ID}
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              e.currentTarget.form?.requestSubmit();
            }
          }}
          aria-describedby={hintId}
          rows={3}
          maxLength={500}
          placeholder="e.g. How do I reset my CampusConnect password?"
          className="w-full resize-y rounded-lg border-2 border-input bg-card px-4 py-3 text-base text-foreground placeholder:text-muted-foreground focus-visible:border-ring"
        />
        <p id={hintId} className="text-sm text-muted-foreground">
          Press Enter to ask, Shift + Enter for a new line. Do not include passwords, recovery
          codes, or student records.
        </p>
        <Button type="submit" size="lg">
          Ask CampusConnect
        </Button>
      </form>

      <div aria-live="polite" className="mt-6 empty:hidden">
        {result && (
          <div className="border-t pt-6">
            <h3 className="sr-only">Answer</h3>
            <ResultView result={result} />
          </div>
        )}
      </div>
    </section>
  );
}
