import { createFileRoute } from "@tanstack/react-router";
import { Info } from "lucide-react";

import { TextAsk } from "@/components/campus/TextAsk";
import { VoiceCard } from "@/components/campus/VoiceCard";
import { VideoCard } from "@/components/campus/VideoCard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CampusConnect Multimodal Help" },
      {
        name: "description",
        content:
          "Ask CampusConnect about approved campus IT help by text or voice, or watch a short orientation video.",
      },
      { property: "og:title", content: "CampusConnect Multimodal Help" },
      {
        property: "og:description",
        content:
          "Approved campus IT help by text or voice, with sources shown and a human handoff when the guide can't answer.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="mx-auto max-w-3xl px-5 py-12 sm:py-16">
      <header>
        <p className="cc-eyebrow">CampusConnect · Classroom prototype</p>
        <h1 className="mt-2 text-4xl font-semibold leading-tight sm:text-5xl">
          CampusConnect Multimodal Help
        </h1>
        <p className="mt-4 max-w-2xl text-lg text-muted-foreground">
          Get approved help with password resets, secure campus Wi-Fi, and the IT Service Desk.
          Guide content is synthetic classroom data, not real university policy.
        </p>
      </header>

      <div className="mt-10 space-y-8">
        <TextAsk />
        <VoiceCard />
        <VideoCard />

        <aside className="cc-handoff flex items-start gap-3 rounded-xl p-5" role="note">
          <Info aria-hidden className="mt-1 size-5 shrink-0" />
          <p className="font-semibold">
            If voice or video is unavailable, type your question. Unsupported questions are
            referred to a human.
          </p>
        </aside>
      </div>
    </main>
  );
}
