/**
 * CampusConnect approved IT Support guide (synthetic classroom data).
 *
 * The text Q&A path answers ONLY from these entries. Retrieval is deterministic
 * so the grounding rules (GR-01, SF-01) stay testable:
 *  - every supported answer cites the source ID, title, owner and review date;
 *  - unsupported questions are never answered and are referred to a human;
 *  - action requests ("reset it for me") are refused with safe steps;
 *  - messages that look like they contain secrets are not processed.
 *
 * Never present these examples as real university policy.
 */

export type GuideSource = {
  id: string;
  title: string;
  owner: string;
  reviewed: string;
  keywords: string[];
  summary: string;
  steps: string[];
};

export const GUIDE_NAME = "CampusConnect IT Support Quick Guide v1";

export const GUIDE: GuideSource[] = [
  {
    id: "IT-01",
    title: "Password reset",
    owner: "IT Support example",
    reviewed: "2026-09-01",
    keywords: ["password", "passwords", "reset", "locked", "lockout", "forgot", "login", "log in", "sign in", "sign-in", "account"],
    summary:
      "You can reset your CampusConnect password yourself through the approved secure self-service portal.",
    steps: [
      "Open the official campus self-service password page from the campus IT website.",
      "Verify your identity using the method you set up earlier.",
      "Choose a new password and sign in again on each of your devices.",
      "If you are still locked out, contact the IT Service Desk. Never share your password with anyone, including staff.",
    ],
  },
  {
    id: "IT-02",
    title: "Secure campus Wi-Fi",
    owner: "IT Support example",
    reviewed: "2026-09-01",
    keywords: ["wifi", "wi-fi", "wireless", "network", "internet", "connect", "connection", "eduroam", "ssid"],
    summary: "Use the secure campus Wi-Fi network and sign in with your campus account.",
    steps: [
      "Choose the secure campus network listed on the campus IT website (not the guest network).",
      "Sign in with your campus username and password when prompted.",
      "If it fails, note your device type, the exact error message and the time it happened.",
      "Share those details with the IT Service Desk so they can help without asking twice.",
    ],
  },
  {
    id: "IT-03",
    title: "IT Service Desk",
    owner: "IT Support example",
    reviewed: "2026-09-01",
    keywords: ["service desk", "help desk", "helpdesk", "it desk", "it support", "ticket", "technician", "talk to someone", "speak to someone", "human", "person", "staff"],
    summary: "The IT Service Desk is the human next step for problems the guide cannot solve.",
    steps: [
      "Use the contact options listed on the official campus IT website.",
      "Describe the problem, your device and any exact error message.",
      "Do not include passwords, recovery codes or student records in your request.",
    ],
  },
];

export const HANDOFF_MESSAGE =
  "The approved guide does not support an answer to this question, so CampusConnect will not guess. It has been referred to a human — please contact the IT Service Desk or the office that owns this topic.";

export const ACTION_MESSAGE =
  "CampusConnect cannot reset accounts, change passwords, open tickets, or access student records. Here are the safe steps you can take yourself.";

export const PRIVACY_MESSAGE =
  "Your question looks like it may contain a password, recovery code, or other private information, so it was not processed. Please remove it and ask again — CampusConnect never needs your password.";

export type AskResult =
  | { kind: "answer"; source: GuideSource }
  | { kind: "action-refused"; source: GuideSource }
  | { kind: "unsupported" }
  | { kind: "private-data" }
  | { kind: "empty" };

const PRIVATE_PATTERNS = [
  /\bmy password is\b/i,
  /\bpassword\s*[:=]/i,
  /\b(recovery|backup|verification|mfa|2fa)\s+code\s*(is|:|=)/i,
  /\b(ssn|social security)\b/i,
  /\b\d{6,}\b/, // long numbers such as student IDs or codes
];

const ACTION_PATTERNS = [
  /\b(for me|on my behalf)\b/i,
  /^\s*(please|can you|could you|will you|would you|i need you to)\b.*\b(reset|change|unlock|open|create|submit|access|look up|fix)\b/i,
];

function normalize(text: string): string {
  return ` ${text.toLowerCase().replace(/[^a-z0-9\s-]/g, " ").replace(/\s+/g, " ")} `;
}

function score(question: string, source: GuideSource): number {
  const q = normalize(question);
  return source.keywords.reduce((total, keyword) => {
    const k = normalize(keyword);
    // Multi-word phrases count double: they are more specific.
    return q.includes(k) ? total + (keyword.includes(" ") ? 2 : 1) : total;
  }, 0);
}

export function findSource(question: string): GuideSource | null {
  let best: GuideSource | null = null;
  let bestScore = 0;
  for (const source of GUIDE) {
    const s = score(question, source);
    if (s > bestScore) {
      best = source;
      bestScore = s;
    }
  }
  return bestScore > 0 ? best : null;
}

export function askGuide(rawQuestion: string): AskResult {
  const question = rawQuestion.trim();
  if (!question) return { kind: "empty" };
  if (PRIVATE_PATTERNS.some((p) => p.test(question))) return { kind: "private-data" };

  const source = findSource(question);
  const isAction = ACTION_PATTERNS.some((p) => p.test(question));

  if (isAction) {
    // Refuse the action; point to the safest relevant guide entry.
    const serviceDesk = GUIDE.find((s) => s.id === "IT-03") as GuideSource;
    return { kind: "action-refused", source: source ?? serviceDesk };
  }
  if (!source) return { kind: "unsupported" };
  return { kind: "answer", source };
}
