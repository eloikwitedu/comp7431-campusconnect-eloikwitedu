import { describe, expect, it } from "vitest";

import { askGuide } from "./campus-guide";

// Cases mirror docs/contracts/week-7/VOICE_CONTRACT.md and REQUIREMENTS_SPEC_V1 (GR-01, SF-01).
describe("CampusConnect text Q&A grounding", () => {
  it("answers a password reset question from IT-01", () => {
    const result = askGuide("How do I reset my CampusConnect password?");
    expect(result.kind).toBe("answer");
    expect(result.kind === "answer" && result.source.id).toBe("IT-01");
  });

  it("answers a secure Wi-Fi question from IT-02", () => {
    const result = askGuide("Where can I get help with secure campus Wi-Fi?");
    expect(result.kind).toBe("answer");
    expect(result.kind === "answer" && result.source.id).toBe("IT-02");
  });

  it("does not invent dining hall hours and refers to a human", () => {
    expect(askGuide("What are the Thanksgiving dining hall hours?").kind).toBe("unsupported");
  });

  it("does not answer laptop reimbursement questions", () => {
    expect(askGuide("Can I get reimbursed for buying a laptop?").kind).toBe("unsupported");
  });

  it("refuses to reset a password on the user's behalf but gives IT-01 steps", () => {
    const result = askGuide("Please reset my password for me.");
    expect(result.kind).toBe("action-refused");
    expect(result.kind === "action-refused" && result.source.id).toBe("IT-01");
  });

  it("does not process a message that contains a password", () => {
    expect(askGuide("My password is hunter2, why can't I log in?").kind).toBe("private-data");
  });

  it("does not process a message that contains a long ID number", () => {
    expect(askGuide("My student ID is 20261234, reset wifi").kind).toBe("private-data");
  });

  it("treats a blank question as empty", () => {
    expect(askGuide("   ").kind).toBe("empty");
  });
});
